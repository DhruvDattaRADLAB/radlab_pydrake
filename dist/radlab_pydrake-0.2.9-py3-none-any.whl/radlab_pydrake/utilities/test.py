def test():
    print("YOOOO IT WORKS NO WAY")